
public interface Sentence_itf {
	
	@Write
	public void write(String text);

	@Read
	public String read();

}
